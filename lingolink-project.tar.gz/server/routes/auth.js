const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { supabase } = require('../config/supabase');
const { registerUser, loginUser, getUserById, checkEmailExists } = require('../services/userService');

// Register route
router.post('/register', async (req, res) => {
  try {
    console.log('Registration request received:', { ...req.body, password: '[REDACTED]' });
    const result = await registerUser(req.body);
    console.log('Registration successful for:', result.user.email);
    res.status(201).json(result);
  } catch (error) {
    console.error('Registration error:', error);
    const statusCode = error.message === 'User already exists' ? 400 : 500;
    res.status(statusCode).json({ message: error.message });
  }
});

// Login route
router.post('/login', async (req, res) => {
  try {
    console.log('Login attempt for:', req.body.email);
    const { email, password } = req.body;
    const result = await loginUser(email, password);
    console.log('Login successful for:', email);
    res.json(result);
  } catch (error) {
    console.error('Login error:', error);
    const statusCode = error.message === 'Invalid credentials' ? 401 : 500;
    res.status(statusCode).json({ message: error.message });
  }
});

// Get current user route
router.get('/me', auth, async (req, res) => {
  try {
    res.json({ user: req.user });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ message: 'Error fetching user', error: error.message });
  }
});

// Check if email exists
router.post('/check-email', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    const exists = await checkEmailExists(email);
    res.json({ exists });
  } catch (error) {
    console.error('Error checking email:', error);
    res.status(500).json({ message: error.message });
  }
});

// Check if email exists with specific user type
router.post('/check-email-type', async (req, res) => {
  try {
    const { email, userType } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    if (!userType || (userType !== 'client' && userType !== 'translator')) {
      return res.status(400).json({ message: 'Valid user type is required' });
    }

    // Check if user exists with this email
    const { data, error } = await supabase
      .from('users')
      .select('user_type')
      .eq('email', email);

    if (error) {
      console.error('Error checking email type:', error);
      throw new Error('Error checking email');
    }

    if (!data || data.length === 0) {
      // Email doesn't exist at all
      return res.json({ exists: false, conflictingType: null });
    }

    // Email exists, check if it's the same type
    const existingUserType = data[0].user_type;
    const exists = existingUserType === userType;
    const conflictingType = exists ? null : existingUserType;

    res.json({ exists, conflictingType });
  } catch (error) {
    console.error('Error checking email type:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;