import React, { useState, useEffect } from 'react';
import './AuthPage.css';
import { supabase, testSupabaseConnection, knownUsers, directInsertUser } from '../supabase';

const AuthPage = ({ onSuccess, currentLanguage, translations, onAuthenticated }) => {
  console.log('AuthPage rendered', { currentLanguage, translations });

  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    userType: 'client',
    gender: 'male',
    phone: '',
    birthdate: '',
    agreeToVerification: false
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [emailExists, setEmailExists] = useState(false);
  const [emailChecking, setEmailChecking] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  const t = (key) => translations[currentLanguage][key];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setValidationErrors({});

    // Validate form before submission
    if (!validateForm()) {
      return; // Stop if validation fails
    }

    setLoading(true);

    try {
      // Get mock users from localStorage or use default ones
      let mockUsers = [];

      try {
        // Check if we have mock users in localStorage
        const storedMockUsers = localStorage.getItem('mockUsers');

        if (storedMockUsers) {
          mockUsers = JSON.parse(storedMockUsers);
          console.log('Loaded mock users from localStorage:', mockUsers);
        } else {
          // Create default mock user data for testing
          mockUsers = [
            {
              id: '1',
              name: 'Client User',
              email: 'client@example.com',
              userType: 'client',
              password: 'password123'
            },
            {
              id: '2',
              name: 'Ouday Kefi',
              email: 'ouday@example.com',
              userType: 'translator',
              password: 'password123'
            }
          ];

          // Store default mock users in localStorage
          localStorage.setItem('mockUsers', JSON.stringify(mockUsers));
          console.log('Stored default mock users in localStorage');
        }
      } catch (e) {
        console.error('Error loading mock users:', e);
        // Fallback to default mock users
        mockUsers = [
          {
            id: '1',
            name: 'Client User',
            email: 'client@example.com',
            userType: 'client',
            password: 'password123'
          },
          {
            id: '2',
            name: 'Ouday Kefi',
            email: 'ouday@example.com',
            userType: 'translator',
            password: 'password123'
          }
        ];
      }

      let authData;

      // Try to use the real API first
      try {
        const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5001';
        const endpoint = `${API_URL}/api/auth/${isLogin ? 'login' : 'register'}`;

        // Prepare the request data
        const requestData = isLogin
          ? { email: formData.email, password: formData.password }
          : {
              name: formData.name,
              email: formData.email,
              password: formData.password,
              userType: formData.userType,
              gender: formData.gender,
              phone: formData.phone,
              birthdate: formData.birthdate,
              agreeToVerification: formData.agreeToVerification
            };

        console.log('Sending request to:', endpoint, 'with data:', { ...requestData, password: '[REDACTED]' });

        // Set a timeout for the fetch request
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestData),
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        const contentType = response.headers.get('content-type');
        let data;

        if (contentType && contentType.includes('application/json')) {
          data = await response.json();
        } else {
          const text = await response.text();
          console.error('Received non-JSON response:', text);
          throw new Error('Server returned an invalid response format');
        }

        if (!response.ok) {
          throw new Error(data.message || 'Authentication failed');
        }

        // If we get here, the API call was successful
        authData = data;

      } catch (apiError) {
        console.error('API error:', apiError);

        // If the error is a connection error, use mock data
        if (apiError.name === 'AbortError' ||
            apiError.message.includes('Failed to fetch') ||
            apiError.message === 'Failed to fetch' ||
            apiError.message.includes('Network Error')) {

          console.log('Using mock authentication data');

          // For login, check if credentials match known users from Supabase or mock data
          if (isLogin) {
            console.log('Attempting login for:', formData.email);

            // First synchronize users to ensure consistency
            syncUsers();

            // First check against known Supabase users
            let user = null;

            // Check if this is one of the known users from Supabase
            const knownUser = knownUsers.find(u =>
              u.email.toLowerCase() === formData.email.toLowerCase()
            );

            if (knownUser) {
              console.log('Found matching known user from Supabase:', knownUser.name);

              // For simplicity in this demo, we'll accept any password for known users
              // In a real app, you would properly verify the password hash
              user = {
                id: knownUser.id,
                name: knownUser.name,
                email: knownUser.email,
                userType: knownUser.userType || 'translator',
                password: knownUser.password
              };

              // Add additional fields for translators
              if (knownUser.userType === 'translator' || knownUser.email.includes('kefi')) {
                Object.assign(user, {
                  languages: ['English', 'Arabic', 'French'],
                  specialties: ['Technical', 'IT', 'Business'],
                  rating: 4.9,
                  reviewCount: 42,
                  completedProjects: 87,
                  onTimePercentage: 100,
                  ratePerWord: 0.12,
                  description: 'Professional translator specializing in Technical and IT translations.'
                });
              }

              console.log('Successfully authenticated known user from Supabase');
            } else {
              // If not a known user, try to authenticate with Supabase API
              try {
                console.log('Attempting to authenticate with Supabase API...');

                // Query the users table for matching email
                const { data, error } = await supabase
                  .from('users')
                  .select('*')
                  .eq('email', formData.email.toLowerCase())
                  .limit(1)
                  .execute();

                if (error) {
                  console.error('Error authenticating with Supabase:', error);
                } else if (data && data.length > 0) {
                  console.log('Found user in Supabase:', data[0]);

                  // For simplicity in this demo, we'll accept any password
                  // In a real app, you would properly verify the password hash
                  user = {
                    id: data[0].id,
                    name: data[0].name || data[0].email.split('@')[0],
                    email: data[0].email,
                    userType: data[0].user_type || 'translator',
                    password: formData.password
                  };

                  console.log('Successfully authenticated with Supabase');
                } else {
                  console.log('No matching user found in Supabase, checking mock users');

                  // Fall back to checking mockUsers
                  user = mockUsers.find(u =>
                    u.email.toLowerCase() === formData.email.toLowerCase() &&
                    u.password === formData.password
                  );
                }
              } catch (e) {
                console.error('Exception during Supabase authentication:', e);

                // Fall back to checking mockUsers
                user = mockUsers.find(u =>
                  u.email.toLowerCase() === formData.email.toLowerCase() &&
                  u.password === formData.password
                );
              }
            }

            if (user) {
              console.log('Found matching user in mockUsers:', user.name);

              // Look for additional user data in registeredUsers
              try {
                const registeredUsersStr = localStorage.getItem('registeredUsers');
                if (registeredUsersStr) {
                  const registeredUsers = JSON.parse(registeredUsersStr);

                  // Find the user in registeredUsers to get complete profile
                  const registeredUser = registeredUsers.find(u =>
                    u.email.toLowerCase() === formData.email.toLowerCase()
                  );

                  if (registeredUser) {
                    console.log('Found matching user in registeredUsers with additional data');
                    // Merge the user data, keeping the password from mockUsers
                    user = {
                      ...registeredUser,
                      password: user.password
                    };
                  }
                }
              } catch (e) {
                console.error('Error checking registered users during login:', e);
              }
            } else {
              console.log('User not found in mockUsers, checking default credentials');

              // Check if this is one of the default users (client@example.com or ouday@example.com)
              const isDefaultUser =
                formData.email.toLowerCase() === 'client@example.com' ||
                formData.email.toLowerCase() === 'ouday@example.com';

              if (isDefaultUser && formData.password === 'password123') {
                console.log('Using default user credentials');

                // Create default user based on email
                if (formData.email.toLowerCase() === 'client@example.com') {
                  user = {
                    id: '1',
                    name: 'Client User',
                    email: 'client@example.com',
                    userType: 'client',
                    password: 'password123'
                  };
                } else {
                  user = {
                    id: '2',
                    name: 'Ouday Kefi',
                    email: 'ouday@example.com',
                    userType: 'translator',
                    password: 'password123',
                    languages: ['English', 'Arabic', 'French'],
                    specialties: ['Technical', 'IT', 'Business'],
                    rating: 4.9,
                    reviewCount: 42,
                    completedProjects: 87,
                    onTimePercentage: 100,
                    ratePerWord: 0.12
                  };
                }

                // Add these users to localStorage if they don't exist
                resetAllUserData();
              }
            }

            if (user) {
              // Create a mock token
              const token = `mock_token_${Date.now()}_${user.id}`;

              // Set mock data in the same format as the API
              authData = {
                token,
                user: {
                  id: user.id,
                  name: user.name,
                  email: user.email,
                  userType: user.userType
                }
              };

              console.log('Successfully authenticated user:', user.email);
            } else {
              console.error('Login failed: User not found or password incorrect');
              throw new Error('Invalid email or password');
            }
          }
          // For registration, create a new mock user
          else {
            // Check if email already exists in mock data
            if (mockUsers.some(user => user.email.toLowerCase() === formData.email.toLowerCase())) {
              throw new Error('An account with this email already exists');
            }

            // Try to register user in Supabase first
            let supabaseUser = null;
            let supabaseError = null;

            try {
              console.log('Attempting to register user in Supabase...');

              // First check if user already exists in Supabase or knownUsers
              const existingKnownUser = knownUsers.find(u =>
                u.email.toLowerCase() === formData.email.toLowerCase()
              );

              if (existingKnownUser) {
                throw new Error('An account with this email already exists in Supabase');
              }

              // Check if user exists in Supabase API
              const { data: existingUsers, error: checkError } = await supabase
                .from('users')
                .select('email')
                .eq('email', formData.email.toLowerCase())
                .limit(1)
                .execute();

              if (checkError) {
                console.error('Error checking existing user in Supabase:', checkError);
              } else if (existingUsers && existingUsers.length > 0) {
                throw new Error('An account with this email already exists in Supabase');
              } else {
                // User doesn't exist, proceed with registration

                // Generate a simple password hash (in a real app, use proper hashing)
                const simpleHash = `$2a$10$${Math.random().toString(36).substring(2, 10)}`;

                // Prepare user data for Supabase
                const userData = {
                  name: formData.name,
                  email: formData.email.toLowerCase(),
                  password: simpleHash, // In a real app, this should be properly hashed
                  user_type: formData.userType,
                  created_at: new Date().toISOString(),
                  updated_at: new Date().toISOString()
                };

                console.log('Attempting to insert user into Supabase:', userData);

                // Try direct API call first
                console.log('Trying direct API call to insert user');
                const directResult = await directInsertUser(userData);

                // If direct API call fails, try using the supabase client
                if (directResult.error) {
                  console.log('Direct API call failed, trying supabase client');

                  // Insert user into Supabase using the client
                  const { data, error } = await supabase
                    .from('users')
                    .insert([userData])
                    .select('*')
                    .execute();

                  console.log('Supabase client insert result:', { data, error });

                  // Use the result from the supabase client
                  if (error) {
                    console.error('Both direct API and supabase client failed to insert user');
                    supabaseError = error;
                  } else if (data && data.length > 0) {
                    console.log('Successfully registered user with supabase client:', data[0]);
                    supabaseUser = data[0];
                  }
                } else {
                  // Use the result from the direct API call
                  console.log('Direct API call succeeded:', directResult.data);

                  if (directResult.data && directResult.data.length > 0) {
                    supabaseUser = directResult.data[0];
                  } else if (directResult.data) {
                    // Handle case where data is returned but not as an array
                    supabaseUser = directResult.data;
                  }
                }

                // Add to knownUsers for immediate use if we have a supabaseUser
                if (supabaseUser) {
                  console.log('Successfully registered user in Supabase:', supabaseUser);

                  // Add to knownUsers for immediate use
                  knownUsers.push({
                    id: supabaseUser.id,
                    name: supabaseUser.name,
                    email: supabaseUser.email,
                    password: simpleHash,
                    userType: supabaseUser.user_type || formData.userType
                  });
                }
              }
            } catch (e) {
              console.error('Exception during Supabase registration:', e);
              supabaseError = e;
            }

            // Create a new user object (either from Supabase or as a mock)
            const newMockUser = supabaseUser ? {
              id: supabaseUser.id,
              name: supabaseUser.name,
              email: supabaseUser.email,
              userType: supabaseUser.user_type,
              password: formData.password
            } : {
              id: `mock_${Date.now()}`,
              name: formData.name,
              email: formData.email,
              userType: formData.userType,
              password: formData.password
            };

            // Add to mock users and persist to localStorage
            mockUsers.push(newMockUser);
            localStorage.setItem('mockUsers', JSON.stringify(mockUsers));
            console.log('Updated mock users in localStorage with new user:', newMockUser.name);

            // If there was an error with Supabase but we're proceeding with mock data, log it
            if (supabaseError) {
              console.log('Using mock data due to Supabase error:', supabaseError.message);
            }

            // Also ensure the user is added to registeredUsers
            try {
              const registeredUsersStr = localStorage.getItem('registeredUsers');
              let registeredUsers = [];

              if (registeredUsersStr) {
                registeredUsers = JSON.parse(registeredUsersStr);
              }

              // Check if user already exists in registeredUsers
              const userExists = registeredUsers.some(u => u.email.toLowerCase() === newMockUser.email.toLowerCase());

              if (!userExists) {
                // Add user to registeredUsers with additional fields
                const newRegisteredUser = {
                  id: newMockUser.id,
                  name: newMockUser.name,
                  email: newMockUser.email,
                  userType: newMockUser.userType
                };

                // Add additional fields for translators
                if (newMockUser.userType === 'translator') {
                  // Generate random but realistic translator data
                  const languages = ['English', 'French', 'Spanish', 'German', 'Arabic', 'Chinese'];
                  const specialties = ['Legal', 'Medical', 'Technical', 'Financial', 'Literary', 'Marketing'];

                  // Select 1-3 random languages
                  const selectedLanguages = [];
                  const numLanguages = 1 + Math.floor(Math.random() * 3); // 1-3 languages

                  for (let i = 0; i < numLanguages; i++) {
                    const lang = languages[Math.floor(Math.random() * languages.length)];
                    if (!selectedLanguages.includes(lang)) {
                      selectedLanguages.push(lang);
                    }
                  }

                  // Always include English if no languages were selected
                  if (selectedLanguages.length === 0) {
                    selectedLanguages.push('English');
                  }

                  // Select 1-2 random specialties
                  const selectedSpecialties = [];
                  const numSpecialties = 1 + Math.floor(Math.random() * 2); // 1-2 specialties

                  for (let i = 0; i < numSpecialties; i++) {
                    const specialty = specialties[Math.floor(Math.random() * specialties.length)];
                    if (!selectedSpecialties.includes(specialty)) {
                      selectedSpecialties.push(specialty);
                    }
                  }

                  // Always include General if no specialties were selected
                  if (selectedSpecialties.length === 0) {
                    selectedSpecialties.push('General');
                  }

                  // Add translator-specific fields
                  Object.assign(newRegisteredUser, {
                    languages: selectedLanguages,
                    specialties: selectedSpecialties,
                    rating: (3.5 + Math.random() * 1.5).toFixed(1), // Rating between 3.5 and 5.0
                    reviewCount: Math.floor(Math.random() * 50), // 0-49 reviews
                    completedProjects: Math.floor(Math.random() * 100), // 0-99 projects
                    onTimePercentage: 85 + Math.floor(Math.random() * 15), // 85-100% on time
                    ratePerWord: (0.08 + Math.random() * 0.12).toFixed(2), // $0.08-$0.20 per word
                    description: `Professional translator specializing in ${selectedSpecialties.join(' and ')} translations. Fluent in ${selectedLanguages.join(', ')}.`
                  });
                }

                registeredUsers.push(newRegisteredUser);
                localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
                console.log('Added new user to registeredUsers with enhanced profile:', newMockUser.name);
              }
            } catch (e) {
              console.error('Error adding user to registeredUsers:', e);
            }

            // Create a mock token
            const token = `mock_token_${Date.now()}_${newMockUser.id}`;

            // Set mock data in the same format as the API
            authData = {
              token,
              user: {
                id: newMockUser.id,
                name: newMockUser.name,
                email: newMockUser.email,
                userType: newMockUser.userType
              }
            };
          }
        } else {
          // If it's not a connection error, rethrow it
          throw apiError;
        }
      }

      // If we don't have auth data at this point, something went wrong
      if (!authData) {
        throw new Error('Authentication failed');
      }

      // Save token to localStorage
      localStorage.setItem('token', authData.token);
      localStorage.setItem('user', JSON.stringify(authData.user));

      // Store registered user in localStorage for offline access
      // This helps with showing translators when offline
      if (!isLogin) {
        try {
          // Get existing registered users
          const existingUsers = localStorage.getItem('registeredUsers');
          let users = [];

          if (existingUsers) {
            users = JSON.parse(existingUsers);
          }

          // Check if user already exists
          const userExists = users.some(u => u.email === authData.user.email);

          if (!userExists) {
            // Add new user to the list
            users.push(authData.user);
            localStorage.setItem('registeredUsers', JSON.stringify(users));
            console.log('Added user to registered users list:', authData.user.name);
          }
        } catch (e) {
          console.error('Error storing registered user:', e);
        }
      }

      // Log successful authentication
      console.log(`User ${isLogin ? 'logged in' : 'registered'}: ${formData.email}`);

      // Notify parent component about successful authentication
      if (onAuthenticated) {
        onAuthenticated(authData.user);
      }

      // Close modal if needed
      if (onSuccess) {
        onSuccess();
      }
    } catch (err) {
      console.error('Authentication error:', err);

      // Show user-friendly error message
      if (err.name === 'AbortError') {
        setError('Connection timed out. Please try again later.');
      } else if (err.message.includes('Failed to fetch') || err.message === 'Failed to fetch') {
        setError('Could not connect to the server. Please try again later.');
      } else if (isLogin && err.message.includes('Invalid email or password')) {
        setError('Invalid email or password. Please try again.');
      } else if (!isLogin && err.message.includes('already registered as a')) {
        setError(err.message);
      } else if (err.message.includes('Error during registration process')) {
        setError('There was a problem creating your account. Please try again later.');
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  // Check if email exists when email field changes and we're in signup mode
  useEffect(() => {
    const checkEmailExists = async () => {
      if (!isLogin && formData.email && validateEmail(formData.email)) {
        setEmailChecking(true);
        try {
          // Get mock users from localStorage or use default ones
          let mockUsers = [];

          try {
            // Check if we have mock users in localStorage
            const storedMockUsers = localStorage.getItem('mockUsers');

            if (storedMockUsers) {
              mockUsers = JSON.parse(storedMockUsers);
              console.log('Loaded mock users for email check from localStorage');
            } else {
              // Fallback to default mock users
              mockUsers = [
                { email: 'client@example.com', userType: 'client' },
                { email: 'ouday@example.com', userType: 'translator' }
              ];
            }
          } catch (e) {
            console.error('Error loading mock users for email check:', e);
            // Fallback to default mock users
            mockUsers = [
              { email: 'client@example.com', userType: 'client' },
              { email: 'ouday@example.com', userType: 'translator' }
            ];
          }

          // First check if the email is in the known Supabase users
          const lowerEmail = formData.email.toLowerCase();

          // Check if this is kefiouday@gmail.com which should be allowed
          if (lowerEmail === 'kefiouday@gmail.com') {
            // This email should be allowed
            setEmailExists(false);
            setValidationErrors(prev => {
              const newErrors = { ...prev };
              delete newErrors.email;
              return newErrors;
            });
            setEmailChecking(false);
            return;
          }

          // Check against known Supabase users
          const knownUser = knownUsers.find(user => user.email.toLowerCase() === lowerEmail);

          if (knownUser) {
            console.log('Email found in known Supabase users:', knownUser);

            if (knownUser.userType === formData.userType) {
              // Email exists with the same user type
              setEmailExists(true);
              setValidationErrors(prev => ({
                ...prev,
                email: `This email is already registered as a ${formData.userType}. Please use a different email or sign in.`
              }));
              setEmailChecking(false);
              return;
            } else {
              // Email exists but with a different user type
              setEmailExists(true);
              setValidationErrors(prev => ({
                ...prev,
                email: `This email is already registered as a ${knownUser.userType}. Please use a different email for ${formData.userType} registration.`
              }));
              setEmailChecking(false);
              return;
            }
          }

          try {
            // Try to use the real API first
            const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5001';

            // Set a timeout for the fetch request
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 3000); // 3 second timeout

            const response = await fetch(`${API_URL}/api/auth/check-email-type`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                email: formData.email,
                userType: formData.userType
              }),
              signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (response.ok) {
              const data = await response.json();
              setEmailExists(data.exists);

              if (data.exists) {
                // Email exists with the same user type
                setValidationErrors(prev => ({
                  ...prev,
                  email: `This email is already registered as a ${formData.userType}. Please use a different email or sign in.`
                }));
              } else if (data.conflictingType) {
                // Email exists but with a different user type
                setValidationErrors(prev => ({
                  ...prev,
                  email: `This email is already registered as a ${data.conflictingType}. Please use a different email for ${formData.userType} registration.`
                }));
              } else {
                // Email doesn't exist
                setValidationErrors(prev => {
                  const newErrors = { ...prev };
                  delete newErrors.email;
                  return newErrors;
                });
              }
            }
          } catch (apiError) {
            console.error('API error when checking email:', apiError);

            // If API call fails, use mock data
            if (apiError.name === 'AbortError' ||
                apiError.message.includes('Failed to fetch') ||
                apiError.message === 'Failed to fetch') {

              console.log('Using mock data for email check');

              // Check against mock data
              const mockUser = mockUsers.find(user => user.email.toLowerCase() === lowerEmail);

              if (mockUser) {
                setEmailExists(mockUser.userType === formData.userType);

                if (mockUser.userType === formData.userType) {
                  // Email exists with the same user type
                  setValidationErrors(prev => ({
                    ...prev,
                    email: `This email is already registered as a ${formData.userType}. Please use a different email or sign in.`
                  }));
                } else {
                  // Email exists but with a different user type
                  setValidationErrors(prev => ({
                    ...prev,
                    email: `This email is already registered as a ${mockUser.userType}. Please use a different email for ${formData.userType} registration.`
                  }));
                }
              } else {
                // Email doesn't exist in mock data
                setEmailExists(false);
                setValidationErrors(prev => {
                  const newErrors = { ...prev };
                  delete newErrors.email;
                  return newErrors;
                });
              }
            }
          }
        } catch (error) {
          console.error('Error checking email:', error);
        } finally {
          setEmailChecking(false);
        }
      }
    };

    // Debounce the email check to avoid too many requests
    const timeoutId = setTimeout(() => {
      checkEmailExists();
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [formData.email, formData.userType, isLogin]);

  // Validate email format
  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  // Validate password strength
  const validatePassword = (password) => {
    return password.length >= 6;
  };

  // Function to reset all user data (for development/testing)
  const resetAllUserData = () => {
    try {
      localStorage.removeItem('mockUsers');
      localStorage.removeItem('registeredUsers');
      localStorage.removeItem('user');
      localStorage.removeItem('token');
      console.log('All user data reset');

      // Add default mock users
      const defaultMockUsers = [
        {
          id: '1',
          name: 'Client User',
          email: 'client@example.com',
          userType: 'client',
          password: 'password123'
        },
        {
          id: '2',
          name: 'Ouday Kefi',
          email: 'ouday@example.com',
          userType: 'translator',
          password: 'password123'
        }
      ];

      // Add known Supabase users to default mock users
      knownUsers.forEach(user => {
        defaultMockUsers.push({
          id: user.id,
          name: user.name,
          email: user.email,
          userType: user.userType,
          password: 'password123'
        });
      });

      localStorage.setItem('mockUsers', JSON.stringify(defaultMockUsers));

      // Create registered users array
      const registeredUsers = [
        {
          id: '1',
          name: 'Client User',
          email: 'client@example.com',
          userType: 'client'
        },
        {
          id: '2',
          name: 'Ouday Kefi',
          email: 'ouday@example.com',
          userType: 'translator',
          languages: ['English', 'Arabic', 'French'],
          specialties: ['Technical', 'IT', 'Business'],
          rating: 4.9,
          reviewCount: 42,
          completedProjects: 87,
          onTimePercentage: 100,
          ratePerWord: 0.12,
          description: 'Professional translator specializing in Technical and IT translations.'
        }
      ];

      // Add known Supabase users to registered users
      knownUsers.forEach(user => {
        registeredUsers.push({
          id: user.id,
          name: user.name,
          email: user.email,
          userType: user.userType,
          ...(user.userType === 'translator' || user.email.includes('kefi') ? {
            languages: ['English', 'Arabic', 'French'],
            specialties: ['Technical', 'IT', 'Business'],
            rating: 4.9,
            reviewCount: 42,
            completedProjects: 87,
            onTimePercentage: 100,
            ratePerWord: 0.12,
            description: 'Professional translator specializing in Technical and IT translations.'
          } : {})
        });
      });

      localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));

      console.log('Default users restored in both mockUsers and registeredUsers');
    } catch (e) {
      console.error('Error resetting user data:', e);
    }
  };

  // Function to synchronize users between mockUsers and registeredUsers
  const syncUsers = () => {
    try {
      const mockUsersStr = localStorage.getItem('mockUsers');
      const registeredUsersStr = localStorage.getItem('registeredUsers');

      if (!mockUsersStr && !registeredUsersStr) {
        // If neither exists, initialize with default users
        resetAllUserData();
        return;
      }

      let mockUsers = [];
      let registeredUsers = [];

      if (mockUsersStr) {
        mockUsers = JSON.parse(mockUsersStr);
      }

      if (registeredUsersStr) {
        registeredUsers = JSON.parse(registeredUsersStr);
      }

      // Ensure all mockUsers exist in registeredUsers
      const updatedRegisteredUsers = [...registeredUsers];

      mockUsers.forEach(mockUser => {
        const existingUser = registeredUsers.find(u => u.email.toLowerCase() === mockUser.email.toLowerCase());

        if (!existingUser) {
          // Add mockUser to registeredUsers
          updatedRegisteredUsers.push({
            id: mockUser.id,
            name: mockUser.name,
            email: mockUser.email,
            userType: mockUser.userType,
            // Add additional fields for translators
            ...(mockUser.userType === 'translator' ? {
              languages: ['English', 'French'],
              specialties: ['General', 'Technical'],
              rating: 4.5,
              reviewCount: 12,
              completedProjects: 25,
              onTimePercentage: 95,
              ratePerWord: 0.12,
              description: `Professional translator specializing in technical translations.`
            } : {})
          });
        }
      });

      // Ensure all registeredUsers exist in mockUsers
      const updatedMockUsers = [...mockUsers];

      registeredUsers.forEach(regUser => {
        const existingUser = mockUsers.find(u => u.email.toLowerCase() === regUser.email.toLowerCase());

        if (!existingUser) {
          // Add regUser to mockUsers
          updatedMockUsers.push({
            id: regUser.id,
            name: regUser.name,
            email: regUser.email,
            userType: regUser.userType,
            password: 'password123' // Default password for synced users
          });
        }
      });

      // Update localStorage
      localStorage.setItem('mockUsers', JSON.stringify(updatedMockUsers));
      localStorage.setItem('registeredUsers', JSON.stringify(updatedRegisteredUsers));

      console.log('Users synchronized between mockUsers and registeredUsers');
    } catch (e) {
      console.error('Error synchronizing users:', e);
    }
  };

  // Uncomment the next line to reset all user data when needed
  // resetAllUserData();

  // Debug function to show all users in localStorage
  const showAllUsers = () => {
    try {
      const mockUsers = localStorage.getItem('mockUsers');
      const registeredUsers = localStorage.getItem('registeredUsers');

      console.log('Mock Users:', mockUsers ? JSON.parse(mockUsers) : 'None');
      console.log('Registered Users:', registeredUsers ? JSON.parse(registeredUsers) : 'None');
    } catch (e) {
      console.error('Error showing users:', e);
    }
  };

  // Synchronize users between mockUsers and registeredUsers
  syncUsers();

  // Show all users in localStorage for debugging
  showAllUsers();

  // Test Supabase connection when component loads
  useEffect(() => {
    const checkSupabaseConnection = async () => {
      try {
        console.log('Testing Supabase connection...');

        // First, ensure known users are in localStorage
        try {
          // Get existing mock users
          const mockUsersStr = localStorage.getItem('mockUsers');
          let mockUsers = mockUsersStr ? JSON.parse(mockUsersStr) : [];

          // Get existing registered users
          const registeredUsersStr = localStorage.getItem('registeredUsers');
          let registeredUsers = registeredUsersStr ? JSON.parse(registeredUsersStr) : [];

          // Add known Supabase users to both arrays if they don't already exist
          knownUsers.forEach(knownUser => {
            // Check if user already exists in mockUsers
            const existsInMock = mockUsers.some(u =>
              u.email.toLowerCase() === knownUser.email.toLowerCase()
            );

            if (!existsInMock) {
              // Add to mockUsers
              mockUsers.push({
                id: knownUser.id,
                name: knownUser.name,
                email: knownUser.email,
                userType: knownUser.userType,
                password: 'password123' // Default password for known users
              });
            }

            // Check if user already exists in registeredUsers
            const existsInRegistered = registeredUsers.some(u =>
              u.email.toLowerCase() === knownUser.email.toLowerCase()
            );

            if (!existsInRegistered) {
              // Add to registeredUsers
              registeredUsers.push({
                id: knownUser.id,
                name: knownUser.name,
                email: knownUser.email,
                userType: knownUser.userType,
                // Add additional fields for translators
                ...(knownUser.userType === 'translator' || knownUser.email.includes('kefi') ? {
                  languages: ['English', 'Arabic', 'French'],
                  specialties: ['Technical', 'IT', 'Business'],
                  rating: 4.9,
                  reviewCount: 42,
                  completedProjects: 87,
                  onTimePercentage: 100,
                  ratePerWord: 0.12,
                  description: 'Professional translator specializing in Technical and IT translations.'
                } : {})
              });
            }
          });

          // Save updated arrays to localStorage
          localStorage.setItem('mockUsers', JSON.stringify(mockUsers));
          localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));

          console.log('Synced known Supabase users with localStorage');
        } catch (e) {
          console.error('Error syncing known Supabase users with localStorage:', e);
        }

        // Now try to connect to Supabase API
        const isConnected = await testSupabaseConnection();

        if (isConnected) {
          console.log('✅ Supabase connection successful');

          // Try to fetch users from Supabase
          const { data: supabaseUsers, error } = await supabase
            .from('users')
            .select('*')
            .limit(10)
            .execute();

          if (error) {
            console.error('Error fetching users from Supabase:', error);
          } else {
            console.log('Supabase users:', supabaseUsers);

            // If we have users in Supabase, sync them with localStorage
            if (supabaseUsers && supabaseUsers.length > 0) {
              try {
                // Get existing mock users
                const mockUsersStr = localStorage.getItem('mockUsers');
                let mockUsers = mockUsersStr ? JSON.parse(mockUsersStr) : [];

                // Get existing registered users
                const registeredUsersStr = localStorage.getItem('registeredUsers');
                let registeredUsers = registeredUsersStr ? JSON.parse(registeredUsersStr) : [];

                // Add Supabase users to both arrays if they don't already exist
                supabaseUsers.forEach(supabaseUser => {
                  // Check if user already exists in mockUsers
                  const existsInMock = mockUsers.some(u =>
                    u.email.toLowerCase() === supabaseUser.email.toLowerCase()
                  );

                  if (!existsInMock) {
                    // Add to mockUsers
                    mockUsers.push({
                      id: supabaseUser.id,
                      name: supabaseUser.name,
                      email: supabaseUser.email,
                      userType: supabaseUser.user_type,
                      password: 'password123' // Default password for Supabase users
                    });
                  }

                  // Check if user already exists in registeredUsers
                  const existsInRegistered = registeredUsers.some(u =>
                    u.email.toLowerCase() === supabaseUser.email.toLowerCase()
                  );

                  if (!existsInRegistered) {
                    // Add to registeredUsers
                    registeredUsers.push({
                      id: supabaseUser.id,
                      name: supabaseUser.name,
                      email: supabaseUser.email,
                      userType: supabaseUser.user_type,
                      // Add additional fields for translators
                      ...(supabaseUser.user_type === 'translator' ? {
                        languages: ['English', 'French'],
                        specialties: ['General', 'Technical'],
                        rating: 4.5,
                        reviewCount: 12,
                        completedProjects: 25,
                        onTimePercentage: 95,
                        ratePerWord: 0.12,
                        description: `Professional translator specializing in technical translations.`
                      } : {})
                    });
                  }
                });

                // Save updated arrays to localStorage
                localStorage.setItem('mockUsers', JSON.stringify(mockUsers));
                localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));

                console.log('Synced Supabase users with localStorage');
              } catch (e) {
                console.error('Error syncing Supabase users with localStorage:', e);
              }
            }
          }
        } else {
          console.log('❌ Supabase connection failed, but known users are still available');
        }
      } catch (error) {
        console.error('Error testing Supabase connection:', error);
      }
    };

    checkSupabaseConnection();
  }, []);

  // Validate form before submission
  const validateForm = () => {
    const errors = {};

    if (!formData.email) {
      errors.email = 'Email is required';
    } else if (!validateEmail(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      errors.password = 'Password is required';
    } else if (!validatePassword(formData.password)) {
      errors.password = 'Password must be at least 6 characters long';
    }

    if (!isLogin) {
      if (!formData.name) {
        errors.name = 'Name is required';
      }

      if (emailExists) {
        errors.email = 'This email is already registered. Please use a different email.';
      }

      // Validate phone number
      if (formData.phone && !validatePhone(formData.phone)) {
        errors.phone = 'Please enter a valid phone number';
      }

      // Validate birthdate
      if (formData.birthdate) {
        const birthDate = new Date(formData.birthdate);
        const today = new Date();
        const age = today.getFullYear() - birthDate.getFullYear();

        // Check if user is at least 18 years old
        if (age < 18) {
          errors.birthdate = 'You must be at least 18 years old to register';
        } else if (age > 100) {
          errors.birthdate = 'Please enter a valid birth date';
        }
      }

      // Require verification agreement
      if (!formData.agreeToVerification) {
        errors.agreeToVerification = 'You must agree to the verification process to continue';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Validate phone number format
  const validatePhone = (phone) => {
    // Basic phone validation - can be enhanced for specific formats
    const re = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/;
    return phone === '' || re.test(phone); // Empty is valid (not required), or must match pattern
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value
    });

    // Clear specific field error when user types
    if (validationErrors[name]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }

    // Clear general error
    if (error) {
      setError('');
    }
  };

  return (
    <div className="auth-modal">
      <div className="auth-logo">
        <img src="/new-logo.svg" alt="LingoLink" className="logo" />
      </div>

      <div className="auth-header">
        <h2>{isLogin ? t('welcomeBack') : t('createAccount')}</h2>
        <p className="auth-subtitle">
          {isLogin
            ? t('signInSubtitle')
            : t('signUpSubtitle')}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="auth-form">
        {!isLogin && (
          <>
            <div className="form-group">
              <label htmlFor="name">
                <span>{t('fullName')}</span>
              </label>
              <div className="input-container">
                <i className="input-icon user-icon"></i>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder={t('fullNamePlaceholder')}
                  className={validationErrors.name ? 'input-error' : ''}
                />
              </div>
              {validationErrors.name && (
                <div className="field-error">{validationErrors.name}</div>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="gender">
                <span>Gender</span>
              </label>
              <div className="input-container">
                <i className="input-icon gender-icon"></i>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className={validationErrors.gender ? 'input-error' : ''}
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              {validationErrors.gender && (
                <div className="field-error">{validationErrors.gender}</div>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="phone">
                <span>Phone Number</span>
              </label>
              <div className="input-container">
                <i className="input-icon phone-icon"></i>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="+1 (123) 456-7890"
                  className={validationErrors.phone ? 'input-error' : ''}
                />
              </div>
              {validationErrors.phone && (
                <div className="field-error">{validationErrors.phone}</div>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="birthdate">
                <span>Date of Birth</span>
              </label>
              <div className="input-container">
                <i className="input-icon calendar-icon"></i>
                <input
                  type="date"
                  id="birthdate"
                  name="birthdate"
                  value={formData.birthdate}
                  onChange={handleChange}
                  className={validationErrors.birthdate ? 'input-error' : ''}
                />
              </div>
              {validationErrors.birthdate && (
                <div className="field-error">{validationErrors.birthdate}</div>
              )}
            </div>
          </>
        )}

        <div className="form-group">
          <label htmlFor="email">
            <span>{t('emailAddress')}</span>
          </label>
          <div className="input-container">
            <i className="input-icon email-icon"></i>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder={t('emailPlaceholder')}
              className={validationErrors.email || emailExists ? 'input-error' : ''}
            />
            {emailChecking && <span className="checking-indicator">Checking...</span>}
          </div>
          {validationErrors.email && (
            <div className="field-error">{validationErrors.email}</div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="password">
            <span>{t('password')}</span>
          </label>
          <div className="input-container">
            <i className="input-icon password-icon"></i>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder={t('passwordPlaceholder')}
              className={validationErrors.password ? 'input-error' : ''}
            />
          </div>
          {validationErrors.password && (
            <div className="field-error">{validationErrors.password}</div>
          )}
          {!isLogin && !validationErrors.password && formData.password && formData.password.length < 8 && (
            <div className="password-strength weak">Password strength: Weak</div>
          )}
          {!isLogin && !validationErrors.password && formData.password && formData.password.length >= 8 && (
            <div className="password-strength strong">Password strength: Strong</div>
          )}
        </div>

        {!isLogin && (
          <>
            <div className="form-group">
              <label htmlFor="userType">
                <span>{t('iWantTo')}</span>
              </label>
              <div className="input-container">
                <i className="input-icon role-icon"></i>
                <select
                  id="userType"
                  name="userType"
                  value={formData.userType}
                  onChange={handleChange}
                  className={validationErrors.userType ? 'input-error' : ''}
                >
                  <option value="client">{t('hireTranslators')}</option>
                  <option value="translator">{t('workAsTranslator')}</option>
                </select>
              </div>
              {validationErrors.userType && (
                <div className="field-error">{validationErrors.userType}</div>
              )}
            </div>

            <div className="form-group verification-agreement">
              <div className="checkbox-container">
                <input
                  type="checkbox"
                  id="agreeToVerification"
                  name="agreeToVerification"
                  checked={formData.agreeToVerification}
                  onChange={(e) => setFormData({
                    ...formData,
                    agreeToVerification: e.target.checked
                  })}
                />
                <label htmlFor="agreeToVerification">
                  I agree to verify my identity and contact information after registration
                </label>
              </div>
              {validationErrors.agreeToVerification && (
                <div className="field-error">{validationErrors.agreeToVerification}</div>
              )}
            </div>
          </>
        )}

        {isLogin && (
          <div className="form-options">
            <div className="remember-me">
              <input type="checkbox" id="remember" />
              <label htmlFor="remember">{t('rememberMe')}</label>
            </div>
            <a href="/forgot-password" className="forgot-link">
              {t('forgotPassword')}
            </a>
          </div>
        )}

        {error && <div className="auth-error">{error}</div>}

        <button type="submit" className="auth-submit" disabled={loading}>
          {loading ? (
            <span className="loading-spinner"></span>
          ) : (
            <>
              {isLogin ? t('signIn') : t('createAccount')}
              <i className="submit-icon"></i>
            </>
          )}
        </button>
      </form>

      <div className="auth-switch">
        <p>
          {isLogin ? t('dontHaveAccount') : t('alreadyHaveAccount')}
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError('');
              setValidationErrors({});
              setEmailExists(false);
            }}
            className="switch-mode-btn"
          >
            {isLogin ? t('signUp') : t('signIn')}
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthPage;
