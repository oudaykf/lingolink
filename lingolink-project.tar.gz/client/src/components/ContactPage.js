const handleContactClick = () => {
  window.location.href = '/apply-translation';
}; 
 
<button onClick={handleContactClick}>Contact</button> 